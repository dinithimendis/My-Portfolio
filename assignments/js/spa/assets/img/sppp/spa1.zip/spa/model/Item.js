class Item {
    constructor(itemCode, itemName, qty, unitPrice) {
        this.itemCode = itemCode;
        this.itemName = itemName;
        this.qty = qty;
        this.unitPrice = unitPrice;
    }
}
