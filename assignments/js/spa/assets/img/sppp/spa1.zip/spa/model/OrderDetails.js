class OrderDetails {
    constructor(oID, date, cID, iCode, oQty, Tot, discount) {
        this.oID = oID;
        this.date = date;
        this.cID = cID;
        this.iCode = iCode;
        this.oQty = oQty;
        this.Tot = Tot;
        this.discount = discount;
    }
}
