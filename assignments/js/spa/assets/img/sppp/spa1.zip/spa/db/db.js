
/** array for storing customer details */
let customerDetails = [];

/** array for storing item details */
let itemDetails = [];

/** array for storing order details */
let orderDetails = [];

/** array for storing order details */
let purchaseDetails = [];