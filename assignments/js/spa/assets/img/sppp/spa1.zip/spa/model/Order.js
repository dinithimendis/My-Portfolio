class Order {
    constructor(iCode, itemName, price, Qty, total, orderId) {
        this.iCode = iCode;
        this.itemName = itemName;
        this.price = price;
        this.Qty = Qty;
        this.total = total;
        this.orderId = orderId;
    }
}