
/** customer id generator */
let customerIdAutoGenerator = 1;
$('#cusIdTxt').val("C-0"+customerIdAutoGenerator);

/** CUSTOMER PAGE OPTIONS  */

/** load all Customer to table */
function loadAllCustomer() {
    
    $("#customerTableBody").empty();

    for (let i of customerDetails) {
        let row = `<tr>
                        <td>${i.id}</td>
                        <td>${i.name}</td>
                        <td>${i.address}</td>
                        <td>${i.contact}</td>
                   </tr>`;
        $('#customerTableBody').append(row);
    }
}

/*
/!** validator for customer id txt  *!/
validator(
    '#cusIdTxt', /^(C-0)[0-9]{1,4}$/,
    "Your input can't be validated, Ex - C-001",
    '#customerIdLbl', '#cusNameTxt'
)

/!** validator for customer name txt  *!/
validator(
    '#cusNameTxt', /^[A-z]{3,30}$/,
    "Your input can't be validated, Ex - mr.Gunawardhana",
    '#customerNameLbl', '#cusAddressTxt'
)

/!** validator for customer address txt  *!/
validator(
    '#cusAddressTxt', /^[A-z]{3,30}$/,
    "Your input can't be validated, Ex - Galle ",
    '#customerAddressLbl', '#cusContactTxt'
)

/!** validator for customer contact txt  *!/
validator(
    '#cusContactTxt', /^(07([1245678])|091)(-)[0-9]{7}$/,
    "Your input can't be validated, Ex - 0719028827",
    '#CustomerContactLbl', '#cusNameTxt'
)
*/

function saveCustomer() {

    let customer = new Customer(
            $('#cusIdTxt').val(),
            $('#cusNameTxt').val(),
            $('#cusAddressTxt').val(),
            $('#cusContactTxt').val()
    );

    customerDetails.push(customer);
    clearTextField('#cusNameTxt,#cusAddressTxt,#cusContactTxt,#cusIdTxt');

    /** saved notification for customer */
    savedSuccessfully();
    loadAllCustomer();
    customerIdAutoGenerator++;
    $('#cusIdTxt').val("C-0"+customerIdAutoGenerator);
    loadAllCustomersToCombo();
}

$("#addCustomerBtn").on('click', function () {
    saveCustomer();
    bindTrEvent();
});

$("#srcCustomerId").on('keydown', function (e) {
    let response = search($("#srcCustomerId").val(), customerDetails);
    let key = e.which;
    if (key === 13) {
        if (response) {
            $("#cusIdTxt").val(response.id);
            $("#cusNameTxt").val(response.name);
            $("#cusAddressTxt").val(response.address);
            $("#cusContactTxt").val(response.contact);
        } else {
            clearTextField('#cusNameTxt,#cusAddressTxt,#cusContactTxt,#cusIdTxt');
            searchResultNotFound();
        }
    }
});

function bindTrEvent() {
    $('#customerTableBody').on('click', 'tr', function () {
        /*console.log($(this));*/
        let cusId = $(this).children(":eq(0)").text();
        let name = $(this).children(":eq(1)").text();
        let address = $(this).children(":eq(2)").text();
        let tel = $(this).children(":eq(3)").text();

        $("#cusIdTxt").val(cusId);
        $("#cusNameTxt").val(name);
        $("#cusAddressTxt").val(address);
        $("#cusContactTxt").val(tel);

    });
}

function deleteCustomer(id){
    for (let i = 0; i < customerDetails.length; i++){
        if (customerDetails[i].id == id){
            customerDetails.splice(i, 1);
            return true;
        }
    }
    return false;
}

$('#deleteCustomerBtn').on('click', function () {
    let id = $('#cusIdTxt').val();

    let consent= confirm("Do you want to delete?");

    if (consent) {
        let response = deleteCustomer(id);
        if (response){
            alert("Success!");
            loadAllCustomer();
        }else {
            alert("Error!");
        }
    }
    clearTextField('#cusNameTxt,#cusAddressTxt,#cusContactTxt,#cusIdTxt,#srcCustomerId');
});

function searchCustomer(id){
   return customerDetails.find(function (customer) {
       return customer.id == id;
   });
}

function updateCustomer(id){
    if (searchCustomer(id) == undefined){
        alert("Please check customerId");
    }else{
        let consent= confirm("Are you sure update this customer.?");
        if (consent) {
            let customer= searchCustomer(id);

            let name = $("#cusNameTxt").val();
            let address = $("#cusAddressTxt").val();
            let tel = $("#cusContactTxt").val();

            customer.name=name;
            customer.address=address;
            customer.contact=tel;

            loadAllCustomer();
        }
    }

}

$('#updateCustomerBtn').on('click', function () {
    let id = $('#cusIdTxt').val();
    updateCustomer(id);

    clearTextField('#cusNameTxt,#cusAddressTxt,#cusContactTxt,#cusIdTxt,#srcCustomerId');
});

// disable tab
$('#cusNameTxt,#cusAddressTxt,#cusContactTxt,#cusIdTxt').on('keydown', function (e) {
    if (e.key == "Tab") {
        e.preventDefault();
    }
});

//enter key
$('#cusNameTxt').on('keydown', function (e) {
    if (e.key =="Enter") {
        $('#cusAddressTxt').focus();
    }
});

$('#cusAddressTxt').on('keydown', function (e) {
    if (e.key =="Enter") {
        $('#cusContactTxt').focus();
    }
});

$('#cusContactTxt').on('keydown', function (e) {
    if (e.key =="Enter") {
        $('#addCustomerBtn').focus();
    }
});


//validation
    const CUS_ID_REGEX =  /^(C-0)[0-9]{1,4}$/;
    const CUS_NAME_REGEX = /^[A-z]{3,30}$/;
    const CUS_ADDRESS_REGEX = /^[A-z]{3,30}$/;
    const CUS_CONTACT_REGEX = /^(07([1245678])|091)(-)[0-9]{7}$/;

    let vArray = new Array();
    vArray.push([$("#cusIdTxt"), CUS_ID_REGEX]);
    vArray.push([$("#cusNameTxt"), CUS_NAME_REGEX]);
    vArray.push([$("#cusAddressTxt"), CUS_ADDRESS_REGEX]);
    vArray.push([$("#cusContactTxt"), CUS_CONTACT_REGEX]);

$("#cusIdTxt,#cusNameTxt,#cusAddressTxt,#cusContactTxt").on('keyup',function () {
        checkValidationsOfAll();
    });

    $("#cusIdTxt").on('keydown',function (e) {
        if (e.key == "Enter") {
            if (checkValidations(vArray[0][0],vArray[0][1])) {
                $("#cusNameTxt").focus();
            }

        }
    });

    $("#cusNameTxt").on('keydown',function (e) {
        if (e.key == "Enter") {
            if (checkValidations(vArray[1][0],vArray[1][1])) {
                $("#cusAddressTxt").focus();
            }

        }
    });

    $("#cusAddressTxt").on('keydown',function (e) {
        if (e.key == "Enter") {
            if (checkValidations(vArray[2][0],vArray[2][1])) {
                $("#cusContactTxt").focus();
            }
        }
    });

    $("#cusContactTxt").on('keydown',function (e) {
        if (e.key == "Enter") {
            if (checkValidations(vArray[3][0],vArray[3][1])) {
                saveCustomer();
            }

        }
    });


    function checkValidationsOfAll() {
        for (let i = 0; i < vArray.length; i++) {
            let field = vArray[i][0];
            let regEx = vArray[i][1];
            if (checkValidations(field, regEx)) {
                field.css("border", "2px solid green");
            } else {
                field.css("border", "2px solid red");
                return;
            }
        }
    }

    function getTheFirstError() {
        for (let i = 0; i < vArray.length; i++) {
            let field = vArray[i][0];
            let regEx = vArray[i][1];
            if (checkValidations(field, regEx)) {
                return field;
            }
        }
        return true;
    }

    function checkValidations(txt, regEx) {
        if (regEx.test(txt.val())) {
            return true;
        }
        return false;
    }